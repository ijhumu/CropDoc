This is a machine learning project. Which main goal is to identify crop disease using CNN algorithm. This app is developed with android native in java. By using Tensorflow Lite model we can predict disease offline. And using firebase we get treatment of the identified disease.


Live demo of the project -->
https://youtu.be/fOpjzP6NxV4